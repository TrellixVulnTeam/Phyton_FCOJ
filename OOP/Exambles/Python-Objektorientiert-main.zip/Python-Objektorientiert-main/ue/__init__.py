from ue1 import Wuerfel

Wuerfel.__init__()
