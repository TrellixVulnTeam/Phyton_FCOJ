class Konto(object):
    def ___init__(self, inhaber, kontonummer, kontostand, kontokorrent=0):
        self.inhaber = inhaber
        self.kontonummer = kontonummer
        self.kontostand = kontostand
        self.kontokorrent = kontokorrent
        print("Hoi")

def ueberweisen(self, ziel, betrag):
    print "hoi"