### Contents of dir

The cert gen shell script is only to build our infrastructure environment. 
The script that we run to build this environment resides in a different repository.
The file `cert_gen.sh` is only used by our infrastructure script for creation of root certificate right now.
Any file in this folder may change or be deleted. So these should not be used anywhere else.
